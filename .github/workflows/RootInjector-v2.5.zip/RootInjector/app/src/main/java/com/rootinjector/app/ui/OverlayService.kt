package com.rootinjector.app.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.rootinjector.app.core.Injector
import com.rootinjector.app.core.Shell
import com.rootinjector.app.core.ShellProvider
import com.rootinjector.app.data.PanelStore
import org.json.JSONObject
import java.io.File
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var statusView: TextView? = null
    private var shell: Shell? = null
    private var pkg = ""
    private var label = ""

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun notif(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("ri", "Floating panel", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "ri") else Notification.Builder(this)
        return b.setContentTitle("Root Injection Panel")
            .setContentText(label)
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        pkg = intent?.getStringExtra("pkg") ?: ""
        label = intent?.getStringExtra("label") ?: pkg
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(7, notif())
        removePanel()
        showPanel()
        return START_NOT_STICKY
    }

    private fun job(): JSONObject = try {
        JSONObject(getSharedPreferences("inj", MODE_PRIVATE).getString("job_$pkg", "{}") ?: "{}")
    } catch (e: Exception) {
        JSONObject()
    }

    private fun status(s: String) { main.post { statusView?.text = s } }

    private fun logLine(s: String) {
        try { File(Injector.ext(this), "log.txt").appendText(s + "\n") } catch (e: Exception) { }
    }

    private fun runSafe(action: (Shell) -> Unit, sh: Shell) {
        try { action(sh) } catch (e: Throwable) { status("✗ ${e.message}") }
    }

    private fun withShell(action: (Shell) -> Unit) {
        val cached = shell
        if (cached != null) {
            Thread { runSafe(action, cached) }.start()
            return
        }
        status("Connecting…")
        ShellProvider.get(job().optBoolean("root", true)) { sh, err ->
            if (sh == null) status("✗ ${err ?: "Connection failed"}")
            else {
                shell = sh
                Thread { runSafe(action, sh) }.start()
            }
        }
    }

    private fun injectFiles() {
        val j = job()
        val dir = j.optString("dir", "")
        val staging = Injector.stagingDir(this)
        val files = staging.walkTopDown().filter { it.isFile }.toList()
        if (dir.isEmpty() || files.isEmpty()) { status("✗ No files selected"); return }
        status("Injecting…")
        withShell { sh ->
            val n = Injector.inject(
                this, sh, { s -> logLine(s) }, pkg, dir, staging, files,
                j.optBoolean("lock", false), j.optBoolean("smart", true), j.optBoolean("backup", true), false
            )
            status(if (n > 0) "✓ Injected $n file(s)" else "✗ Failed")
        }
    }

    private fun injectPanel() {
        val j = job()
        val id = j.optString("panel", "")
        val p = if (id.isEmpty()) null else PanelStore.load(File(PanelStore.root(this), id))
        if (p == null) { status("✗ No panel selected"); return }
        status("Injecting…")
        withShell { sh ->
            val r = Injector.injectPanel(
                this, sh, { s -> logLine(s) }, pkg, p, j.optBoolean("root", true),
                j.optBoolean("smart", true), j.optBoolean("backup", true), false
            )
            status(r)
        }
    }

    private fun deleteInjected() {
        status("Deleting…")
        withShell { sh ->
            val n = Injector.delete(this, sh, { s -> logLine(s) }, pkg)
            status(if (n > 0) "✓ Deleted $n file(s)" else "Nothing injected yet")
        }
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        panel = null
    }

    private fun showPanel() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(12)
        lp.y = dp(160)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = shape(Ui.CARD, 18)
        root.setPadding(dp(8), dp(8), dp(8), dp(8))

        val head = tv("⚡ $label", 13f, Ui.TEXT, true)
        head.setPadding(dp(8), dp(6), dp(8), dp(6))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.visibility = View.GONE
        body.minimumWidth = dp(200)
        val st = tv("Ready", 12f, Ui.SUB)
        statusView = st
        body.addView(st)
        body.addView(btn("Inject Files", 1) { injectFiles() })
        body.addView(btn("Inject Panel", 1) { injectPanel() })
        body.addView(btn("Delete Injected", 2) { deleteInjected() })
        body.addView(btn("Close") { stopSelf() })

        root.addView(head)
        root.addView(body)

        head.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx
                        lp.y = sy + dy
                        wm.updateViewLayout(root, lp)
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            body.visibility = if (body.visibility == View.GONE) View.VISIBLE else View.GONE
                            wm.updateViewLayout(root, lp)
                        }
                    }
                }
                return true
            }
        })

        wm.addView(root, lp)
        panel = root
    }

    override fun onDestroy() {
        removePanel()
        super.onDestroy()
    }
}
