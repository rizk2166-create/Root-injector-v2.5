package com.rootinjector.app.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val BG = Color.parseColor("#0F1319")
    val CARD = Color.parseColor("#1A212B")
    val FIELD = Color.parseColor("#2A3441")
    val ACCENT = Color.parseColor("#4F8CFF")
    val DANGER = Color.parseColor("#C93C41")
    val TEXT = Color.parseColor("#E8ECF1")
    val SUB = Color.parseColor("#8B97A6")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.shape(color: Int, radius: Int = 12): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

fun Context.tv(text: String, size: Float = 14f, color: Int = Ui.TEXT, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(3), 0, dp(3))
    }

fun Context.card(title: String): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = shape(Ui.CARD, 16)
    c.setPadding(dp(14), dp(12), dp(14), dp(14))
    c.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
    c.addView(tv(title, 12f, Ui.ACCENT, true))
    return c
}

// kind: 0 = biasa, 1 = utama (biru), 2 = bahaya (merah)
fun Context.btn(text: String, kind: Int = 0, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setAllCaps(false)
    b.textSize = 14f
    b.setTextColor(Color.WHITE)
    b.background = shape(if (kind == 1) Ui.ACCENT else if (kind == 2) Ui.DANGER else Ui.FIELD, 10)
    b.minHeight = dp(44)
    b.minimumHeight = dp(44)
    b.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    b.setOnClickListener { onClick() }
    return b
}

fun Context.row(vararg views: View): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    r.layoutParams = LinearLayout.LayoutParams(-1, -2)
    for (v in views) {
        v.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(8); marginEnd = dp(6) }
        r.addView(v)
    }
    return r
}

fun Context.edit(hint: String): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setHintTextColor(Ui.SUB)
    e.setTextColor(Ui.TEXT)
    e.textSize = 14f
    e.background = shape(Ui.FIELD, 10)
    e.setPadding(dp(12), dp(10), dp(12), dp(10))
    e.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    return e
}

fun Context.gradient(c1: Int, c2: Int, radius: Int = 16): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)).apply {
        cornerRadius = dp(radius).toFloat()
    }

fun Context.chip(text: String, bg: Int): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = 10f
    t.setTextColor(Color.WHITE)
    t.setTypeface(t.typeface, Typeface.BOLD)
    t.setPadding(dp(8), dp(2), dp(8), dp(2))
    t.background = shape(bg, 8)
    return t
}
