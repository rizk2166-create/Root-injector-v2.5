package com.rootinjector.app.core

import android.content.Context
import com.rootinjector.app.data.GameRepository
import com.rootinjector.app.data.PanelDef
import java.io.File

object Injector {
    fun ext(ctx: Context): File = ctx.getExternalFilesDir(null) ?: ctx.filesDir
    fun stagingDir(ctx: Context): File = File(ext(ctx), "staging").apply { mkdirs() }
    fun backupRoot(ctx: Context): String = File(ext(ctx), "backup").absolutePath
    private fun manifest(ctx: Context, pkg: String) = File(ext(ctx), "injected/$pkg.txt")

    fun injected(ctx: Context, pkg: String): List<String> {
        val m = manifest(ctx, pkg)
        return if (m.exists()) m.readLines().filter { it.isNotBlank() } else emptyList()
    }

    fun panelDir(ctx: Context, p: PanelDef, pkg: String, useRoot: Boolean): String? {
        val cfg = GameRepository.loadConfig(ctx)
        val idx = when (p.dirKind) { "data" -> 1; "obb" -> 2; "internal" -> 3; else -> 0 }
        val t = cfg.targets[idx.coerceAtMost(cfg.targets.size - 1)]
        if (t.needsRoot && !useRoot) return null
        var d = t.path.replace("{pkg}", pkg)
        val sub = p.sub.trim().trim('/')
        if (sub.isNotEmpty()) d += "/$sub"
        return d
    }

    fun inject(
        ctx: Context, sh: Shell, log: (String) -> Unit, pkg: String, dir: String,
        root: File, files: List<File>, lock: Boolean, smart: Boolean, backup: Boolean, stop: Boolean
    ): Int {
        val eng = ActionEngine(sh, log)
        if (stop) { sh.exec("am force-stop $pkg"); log("App force-stopped") }
        val done = eng.inject(pkg, dir, root, files, lock, if (backup) backupRoot(ctx) else null, smart)
        if (done.isNotEmpty()) {
            val m = manifest(ctx, pkg)
            m.parentFile?.mkdirs()
            val map = LinkedHashMap<String, String>()
            (injected(ctx, pkg) + done).forEach { map[it.substringBefore('\t')] = it }
            m.writeText(map.values.joinToString("\n") + "\n")
        }
        return done.size
    }

    fun injectPanel(
        ctx: Context, sh: Shell, log: (String) -> Unit, pkg: String, p: PanelDef,
        useRoot: Boolean, smart: Boolean, backup: Boolean, stop: Boolean
    ): String {
        if (!p.isInject && !p.isScript) return "✗ Invalid panel: no files and no script"
        val dir = panelDir(ctx, p, pkg, useRoot) ?: return "✗ This panel needs Root mode"
        var ok = true
        if (p.isInject) {
            val n = inject(ctx, sh, log, pkg, dir, p.dir, p.files, p.lock, smart, backup, stop)
            if (n == 0) ok = false
        }
        if (p.isScript) ActionEngine(sh, log).runScript(pkg, dir, p.dir.absolutePath, p.script)
        return if (ok) "✓ Done" else "✗ Failed — see log"
    }

    fun delete(ctx: Context, sh: Shell, log: (String) -> Unit, pkg: String): Int {
        val entries = injected(ctx, pkg)
        if (entries.isEmpty()) { log("Nothing injected yet"); return 0 }
        ActionEngine(sh, log).uninject(pkg, entries.map { it.substringBefore('\t') }, backupRoot(ctx))
        manifest(ctx, pkg).delete()
        return entries.size
    }
}
