package com.rootinjector.app.core

data class ShellResult(val code: Int, val out: String)

interface Shell {
    fun exec(cmd: String): ShellResult
}

class RootShell : Shell {
    override fun exec(cmd: String): ShellResult = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText().trim()
        ShellResult(p.waitFor(), out)
    } catch (e: Exception) {
        ShellResult(-1, e.message ?: "su gagal")
    }
}
