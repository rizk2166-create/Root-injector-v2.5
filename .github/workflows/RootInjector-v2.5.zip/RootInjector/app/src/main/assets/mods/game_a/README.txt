Taruh file mod bawaan di assets/mods/<nama.paket.app>/ lalu build ulang. Contoh: assets/mods/com.tencent.ig/
