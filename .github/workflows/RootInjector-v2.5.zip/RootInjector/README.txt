RootInjector v2.5
1. Buka folder ini di Android Studio (Hedgehog+ / JDK 17), tunggu Gradle sync.
2. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
3. Mod bawaan: taruh file di app/src/main/assets/mods/<package.name.app>/
4. Edit target/junk default di app/src/main/assets/config.json
Mode Shizuku: bisa tulis ke Android/data & Android/obb. Mode Root: tambah /data/data.

Tanpa Android Studio: upload folder ini ke GitHub, tab Actions > Build APK > download artifact RootInjector-apk.
