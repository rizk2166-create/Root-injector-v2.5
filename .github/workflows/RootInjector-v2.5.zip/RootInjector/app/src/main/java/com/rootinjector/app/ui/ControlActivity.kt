package com.rootinjector.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import androidx.documentfile.provider.DocumentFile
import com.rootinjector.app.core.ActionEngine
import com.rootinjector.app.core.Injector
import com.rootinjector.app.core.RootShell
import com.rootinjector.app.core.Shell
import com.rootinjector.app.core.ShizukuConnector
import com.rootinjector.app.data.Config
import com.rootinjector.app.data.GameRepository
import com.rootinjector.app.data.PanelDef
import com.rootinjector.app.data.PanelStore
import com.rootinjector.app.data.Target
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

class ControlActivity : Activity() {
    private val STORAGE = "/storage/emulated/0"

    private lateinit var pkg: String
    private lateinit var appLabel: String
    private lateinit var cfg: Config

    private lateinit var logView: TextView
    private lateinit var stagedView: TextView
    private lateinit var pathView: TextView
    private lateinit var targetSpinner: Spinner
    private lateinit var panelSpinner: Spinner
    private lateinit var presetSpinner: Spinner
    private lateinit var subEdit: EditText
    private lateinit var scriptEdit: EditText
    private lateinit var lockCheck: CheckBox
    private lateinit var backupCheck: CheckBox
    private lateinit var stopCheck: CheckBox
    private lateinit var smartCheck: CheckBox
    private lateinit var zipCheck: CheckBox
    private lateinit var modeGroup: RadioGroup
    private lateinit var btnFiles: Button
    private lateinit var btnPanel: Button
    private var idShizuku = 0
    private var idRoot = 0
    private var panels: List<PanelDef> = emptyList()
    private var presets: List<String> = emptyList()
    @Volatile private var shellOk = false

    private val ext: File get() = Injector.ext(this)
    private fun stagingDir(): File = Injector.stagingDir(this)
    private fun presetRoot(): File = File(ext, "profiles/$pkg").apply { mkdirs() }
    private fun stagedFiles(): List<File> = stagingDir().walkTopDown().filter { it.isFile }.sortedBy { it.path }.toList()
    private fun rel(f: File): String = f.relativeTo(stagingDir()).path.replace(File.separatorChar, '/')
    private fun safeName(n: String): String = n.replace('/', '_').replace('\\', '_').ifBlank { "file" }
    private fun fmt(b: Long): String = when {
        b >= 1048576L -> "%.1f MB".format(b / 1048576.0)
        b >= 1024L -> "${b / 1024} KB"
        else -> "$b B"
    }
    private fun isRoot(): Boolean = modeGroup.checkedRadioButtonId == idRoot

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pkg = intent.getStringExtra("pkg") ?: run { finish(); return }
        appLabel = intent.getStringExtra("label") ?: pkg
        cfg = GameRepository.loadConfig(this)
        window.statusBarColor = Ui.BG

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(8), dp(14), dp(28))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.fitsSystemWindows = true
        scroll.addView(col)
        setContentView(scroll)

        // ---- header ----
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(0, dp(8), 0, dp(4))
        val icon = ImageView(this)
        icon.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (e: Exception) { }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12), 0, 0, 0)
        titles.addView(tv(appLabel, 20f, Ui.TEXT, true))
        val pkgView = tv(pkg, 12f, Ui.SUB)
        pkgView.setTextIsSelectable(true)
        titles.addView(pkgView)
        header.addView(icon); header.addView(titles)
        col.addView(header)

        // ---- mode ----
        val cMode = card("MODE")
        idShizuku = View.generateViewId(); idRoot = View.generateViewId()
        modeGroup = RadioGroup(this)
        modeGroup.orientation = RadioGroup.HORIZONTAL
        val rbS = RadioButton(this); rbS.id = idShizuku; rbS.text = "Shizuku"; rbS.setTextColor(Ui.TEXT)
        val rbR = RadioButton(this); rbR.id = idRoot; rbR.text = "Root"; rbR.setTextColor(Ui.TEXT)
        modeGroup.addView(rbS); modeGroup.addView(rbR)
        val prefs = getSharedPreferences("inj", MODE_PRIVATE)
        modeGroup.check(if (prefs.getBoolean("mode_root", true)) idRoot else idShizuku)
        modeGroup.setOnCheckedChangeListener { _, _ ->
            shellOk = false
            getSharedPreferences("inj", MODE_PRIVATE).edit().putBoolean("mode_root", isRoot()).apply()
            updateReady()
        }
        cMode.addView(modeGroup)
        cMode.addView(row(
            btn("Test") { withShell { sh -> log("✓ Connected → ${sh.exec("id").out}") } },
            btn("Diagnose") {
                val d = fullDir(cfg.targets[targetSpinner.selectedItemPosition])
                val st = stagingDir().absolutePath
                withShell { ActionEngine(it, ::log).diagnose(pkg, d, st) }
            }
        ))
        col.addView(cMode)

        // ---- target ----
        val cTarget = card("TARGET")
        targetSpinner = Spinner(this)
        targetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            cfg.targets.map { it.label.replace("{pkg}", pkg) })
        targetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { updatePath() }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        cTarget.addView(targetSpinner)
        subEdit = edit("Subfolder (optional)")
        subEdit.doAfterTextChanged { updatePath() }
        cTarget.addView(subEdit)
        pathView = tv("", 11f, Ui.SUB)
        pathView.typeface = Typeface.MONOSPACE
        pathView.setTextIsSelectable(true)
        cTarget.addView(pathView)
        cTarget.addView(btn("Browse folders") { browse(null) })
        col.addView(cTarget)

        // ---- files ----
        val cFiles = card("FILES")
        cFiles.addView(btn("Pick from storage", 1) { storageBrowse("$STORAGE/Download") })
        cFiles.addView(row(btn("Add Files") { pickFiles() }, btn("Add Folder") { pickFolder() }))
        val bundled = GameRepository.bundledMods(this, pkg)
        if (bundled.isNotEmpty()) cFiles.addView(btn("Bundled files (${bundled.size})") { stageBundled(bundled) })
        zipCheck = CheckBox(this)
        zipCheck.text = "Extract .zip"
        zipCheck.setTextColor(Ui.TEXT)
        zipCheck.isChecked = true
        cFiles.addView(zipCheck)
        stagedView = tv("", 13f, Ui.TEXT)
        cFiles.addView(stagedView)
        cFiles.addView(row(btn("Manage") { manage() }, btn("Clear", 2) { clearStaged() }))
        cFiles.addView(btn("Check Files") { checkStagedUi() })
        col.addView(cFiles)

        // ---- panel ----
        val cPanel = card("PANEL")
        panelSpinner = Spinner(this)
        panelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { updateReady() }
            override fun onNothingSelected(p: AdapterView<*>?) { }
        }
        cPanel.addView(panelSpinner)
        cPanel.addView(row(btn("Import") { showImportMenu() }, btn("Delete", 2) { deletePanel() }))
        col.addView(cPanel)

        // ---- presets ----
        val cPreset = card("PRESETS")
        presetSpinner = Spinner(this)
        cPreset.addView(presetSpinner)
        cPreset.addView(row(btn("Save") { savePreset() }, btn("Load") { loadPreset() }, btn("Delete", 2) { deletePreset() }))
        col.addView(cPreset)

        // ---- script ----
        val cScript = card("SCRIPT")
        scriptEdit = edit("Shell script")
        scriptEdit.minLines = 3
        scriptEdit.gravity = Gravity.TOP
        scriptEdit.typeface = Typeface.MONOSPACE
        scriptEdit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        cScript.addView(scriptEdit)
        cScript.addView(row(btn("Run") { runScriptNow() }, btn("Clear") { scriptEdit.setText("") }))
        col.addView(cScript)

        // ---- options ----
        val cOpt = card("OPTIONS")
        smartCheck = CheckBox(this)
        smartCheck.text = "Smart match"
        smartCheck.setTextColor(Ui.TEXT)
        smartCheck.isChecked = true
        stopCheck = CheckBox(this)
        stopCheck.text = "Force-stop app"
        stopCheck.setTextColor(Ui.TEXT)
        stopCheck.isChecked = true
        backupCheck = CheckBox(this)
        backupCheck.text = "Backup originals"
        backupCheck.setTextColor(Ui.TEXT)
        backupCheck.isChecked = true
        lockCheck = CheckBox(this)
        lockCheck.text = "Lock files"
        lockCheck.setTextColor(Ui.TEXT)
        cOpt.addView(smartCheck); cOpt.addView(stopCheck); cOpt.addView(backupCheck); cOpt.addView(lockCheck)
        col.addView(cOpt)

        // ---- actions ----
        val cAct = card("ACTIONS")
        btnFiles = btn("Inject Files") { onInjectTap(false) }
        btnPanel = btn("Inject Panel") { onInjectTap(true) }
        cAct.addView(btnFiles)
        cAct.addView(btnPanel)
        cAct.addView(btn("Floating Panel", 1) { openFloating() })
        cAct.addView(row(btn("Restore") { doRestore() }, btn("Unlock") { doUnlock() }))
        cAct.addView(row(btn("Check & Repair") { doCheck() }, btn("Delete Injected", 2) { confirmDeleteInjected() }))
        cAct.addView(row(btn("Open App") { openApp() }, btn("Clear Cache", 2) {
            AlertDialog.Builder(this).setTitle("Clear cache of $appLabel?")
                .setMessage(cfg.junk.joinToString("\n") { it.replace("{pkg}", pkg) })
                .setPositiveButton("Clear") { _, _ -> doClean() }
                .setNegativeButton("Cancel", null).show()
        }))
        col.addView(cAct)

        // ---- log ----
        val cLog = card("LOG")
        logView = tv("", 12f, Ui.TEXT)
        logView.typeface = Typeface.MONOSPACE
        logView.setTextIsSelectable(true)
        cLog.addView(row(btn("Copy") { copyLog() }, btn("Clear") { logView.text = "" }))
        cLog.addView(logView)
        col.addView(cLog)

        updatePath()
        refreshStaged()
        refreshPanels()
        refreshPresets()
    }

    override fun onResume() {
        super.onResume()
        if (::btnFiles.isInitialized) updateReady()
    }

    // ---------------- util ----------------
    private fun log(s: String) {
        runOnUiThread { logView.append(s + "\n") }
        try { File(ext, "log.txt").appendText(s + "\n") } catch (e: Exception) { }
    }

    private fun toast(s: String) { runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_LONG).show() } }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", logView.text))
        toast("Log copied")
    }

    private fun openApp() {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else log("✗ Cannot open $pkg")
    }

    private fun fullDir(t: Target): String {
        var d = t.path.replace("{pkg}", pkg)
        val sub = subEdit.text.toString().trim().trim('/')
        if (sub.isNotEmpty()) d += "/$sub"
        return d
    }

    private fun updatePath() {
        if (!::pathView.isInitialized || !::subEdit.isInitialized || !::targetSpinner.isInitialized) return
        val t = cfg.targets.getOrNull(targetSpinner.selectedItemPosition) ?: return
        pathView.text = fullDir(t)
    }

    private fun resolveDir(): String? {
        val t = cfg.targets[targetSpinner.selectedItemPosition]
        if (t.needsRoot && !isRoot()) {
            log("✗ This folder needs Root mode."); return null
        }
        return fullDir(t)
    }

    private fun selectedPanel(): PanelDef? = panels.getOrNull(panelSpinner.selectedItemPosition)

    // Inject buttons: grey until everything is ready, blue when ready
    private fun updateReady() {
        runOnUiThread {
            if (!::btnFiles.isInitialized || !::panelSpinner.isInitialized) return@runOnUiThread
            val base = Settings.canDrawOverlays(this) && shellOk
            btnFiles.background = shape(if (base && stagedFiles().isNotEmpty()) Ui.ACCENT else Ui.FIELD, 10)
            btnPanel.background = shape(if (base && selectedPanel() != null) Ui.ACCENT else Ui.FIELD, 10)
        }
    }

    private fun refreshStaged() {
        runOnUiThread {
            val fs = stagedFiles()
            stagedView.text = if (fs.isEmpty()) "No files selected"
            else "${fs.size} file(s) • ${fmt(fs.sumOf { it.length() })}\n" +
                fs.take(8).joinToString("\n") { "• " + rel(it) } +
                (if (fs.size > 8) "\n… +${fs.size - 8} more" else "")
        }
        updateReady()
    }

    private fun refreshPanels() {
        panels = PanelStore.list(this)
        panelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            if (panels.isEmpty()) listOf("(no panels)") else panels.map { it.name })
        updateReady()
    }

    // ---------------- shell ----------------
    private fun withShell(action: (Shell) -> Unit) {
        if (isRoot()) {
            Thread {
                val sh = RootShell()
                val r = sh.exec("id")
                if (r.code == 0 && r.out.contains("uid=0")) {
                    shellOk = true
                    updateReady()
                    try { action(sh) } catch (e: Throwable) { log("✗ Error: ${e.message}") }
                } else {
                    shellOk = false
                    log("✗ Root unavailable or denied: ${r.out}")
                }
            }.start()
        } else {
            ShizukuConnector.connect { sh, err ->
                if (sh == null) {
                    shellOk = false
                    log("✗ ${err ?: "Shizuku failed"}")
                } else {
                    shellOk = true
                    updateReady()
                    Thread {
                        try { action(sh) } catch (e: Throwable) { log("✗ Error: ${e.message}") }
                    }.start()
                }
            }
        }
    }

    // ---------------- inject buttons ----------------
    private fun onInjectTap(panelMode: Boolean) {
        if (panelMode) {
            if (selectedPanel() == null) { toast("Import a panel first"); showImportMenu(); return }
        } else if (stagedFiles().isEmpty()) {
            toast("Select files first"); pickFiles(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\"")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!shellOk) {
            withShell { log("✓ ${if (isRoot()) "Root" else "Shizuku"} allowed") }
            return
        }
        if (panelMode) confirmInjectPanel() else confirmInjectFiles()
    }

    private fun confirmInjectFiles() {
        val files = stagedFiles()
        val dir = resolveDir() ?: return
        val problems = findProblems(files)
        var msg = "$pkg\n${dir.removePrefix(STORAGE)}\n${files.size} file(s)"
        if (problems.isNotEmpty()) {
            msg += "\n\nSkipping ${problems.size} damaged file(s):\n" +
                problems.entries.joinToString("\n") { "• ${it.key.name}: ${it.value}" }
        }
        AlertDialog.Builder(this).setTitle("Inject into $appLabel?").setMessage(msg)
            .setPositiveButton("Inject") { _, _ -> injectNow(files.filter { it !in problems.keys }, dir) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun injectNow(files: List<File>, dir: String) {
        if (files.isEmpty()) { log("✗ No valid files to inject."); return }
        val root = stagingDir()
        val lock = lockCheck.isChecked
        val smart = smartCheck.isChecked
        val backup = backupCheck.isChecked
        val stop = stopCheck.isChecked
        log("→ Injecting ${files.size} file(s) into $appLabel")
        withShell { sh ->
            Injector.inject(this, sh, ::log, pkg, dir, root, files, lock, smart, backup, stop)
        }
    }

    private fun confirmInjectPanel() {
        val p = selectedPanel() ?: return
        if (!p.isInject && !p.isScript) {
            toast("✗ Invalid panel: no files and no script")
            log("✗ ${p.name}: the panel has no files and no script")
            return
        }
        val dir = Injector.panelDir(this, p, pkg, isRoot())
        if (dir == null) { toast("✗ This panel needs Root mode"); return }
        var msg = "$pkg\n${dir.removePrefix(STORAGE)}\n${p.files.size} file(s)" + (if (p.isScript) " + script" else "")
        if (p.target.isNotBlank() && p.target != pkg) msg += "\n\n⚠ Made for ${p.target}"
        AlertDialog.Builder(this).setTitle("Inject \"${p.name}\"?").setMessage(msg)
            .setPositiveButton("Inject") { _, _ -> injectPanelNow(p) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun injectPanelNow(p: PanelDef) {
        val root = isRoot()
        val smart = smartCheck.isChecked
        val backup = backupCheck.isChecked
        val stop = stopCheck.isChecked
        log("→ Panel \"${p.name}\" → $appLabel")
        withShell { sh ->
            log(Injector.injectPanel(this, sh, ::log, pkg, p, root, smart, backup, stop))
        }
    }

    private fun confirmDeleteInjected() {
        val entries = Injector.injected(this, pkg).map { it.substringBefore('\t') }
        if (entries.isEmpty()) { toast("Nothing injected yet"); return }
        val shown = entries.take(15).joinToString("\n") { it.removePrefix("$STORAGE/Android/") }
        val more = if (entries.size > 15) "\n… +${entries.size - 15} more" else ""
        AlertDialog.Builder(this).setTitle("Delete ${entries.size} injected file(s)?")
            .setMessage("$pkg\n\n$shown$more")
            .setPositiveButton("Delete") { _, _ ->
                withShell { sh -> Injector.delete(this, sh, ::log, pkg) }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun openFloating() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow \"Display over other apps\", then tap again")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val dir = resolveDir() ?: ""
        val job = JSONObject()
            .put("dir", dir)
            .put("root", isRoot())
            .put("lock", lockCheck.isChecked)
            .put("smart", smartCheck.isChecked)
            .put("backup", backupCheck.isChecked)
            .put("panel", selectedPanel()?.id ?: "")
        getSharedPreferences("inj", MODE_PRIVATE).edit().putString("job_$pkg", job.toString()).apply()
        val i = Intent(this, OverlayService::class.java).putExtra("pkg", pkg).putExtra("label", appLabel)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    // ---------------- storage picker (ZArchiver, Download, ...) ----------------
    private fun storageBrowse(dir: String) {
        if (!dir.startsWith(STORAGE) || dir.contains("..")) { log("✗ Outside storage: $dir"); return }
        withShell { sh ->
            val res = ActionEngine(sh, ::log).listDir(dir)
            if (res == null) { log("✗ Cannot open $dir"); return@withShell }
            val dirs = res.first
            val files = res.second
            val items = (listOf("⬆ Up", "✔ Use this folder", "✔ Add all files here")
                + dirs.map { "📁 $it" } + files.map { "📄 $it" }).toTypedArray()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(dir.removePrefix(STORAGE).ifEmpty { "/" })
                    .setItems(items) { _, which ->
                        if (which == 0) {
                            val parent = dir.substringBeforeLast('/')
                            storageBrowse(if (parent.length < STORAGE.length) dir else parent)
                        } else if (which == 1) {
                            addFromStorage(listOf(dir), dir)
                        } else if (which == 2) {
                            addFromStorage(files.map { "$dir/$it" }, dir)
                        } else if (which < 3 + dirs.size) {
                            storageBrowse("$dir/${dirs[which - 3]}")
                        } else {
                            fileTap(dir, files[which - 3 - dirs.size])
                        }
                    }
                    .setNegativeButton("Close", null).show()
            }
        }
    }

    private fun fileTap(dir: String, name: String) {
        val lower = name.lowercase()
        val isScript = lower.endsWith(".sh") || lower.endsWith(".txt")
        val opts = if (isScript) arrayOf("Add to list", "Load as script") else arrayOf("Add to list")
        AlertDialog.Builder(this).setTitle(name).setItems(opts) { _, w ->
            if (w == 0) addFromStorage(listOf("$dir/$name"), dir)
            else withShell { sh ->
                val text = ActionEngine(sh, ::log).readFile("$dir/$name")
                runOnUiThread { scriptEdit.setText(text); log("✓ Script loaded: $name") }
            }
        }.setNegativeButton("Cancel") { _, _ -> storageBrowse(dir) }.show()
    }

    private fun addFromStorage(srcs: List<String>, again: String) {
        if (srcs.isEmpty()) { log("No files here."); storageBrowse(again); return }
        val zip = zipCheck.isChecked
        val st = stagingDir().absolutePath
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            for (s in srcs) {
                val r = eng.copyIn(s, st)
                if (r.code != 0) log("✗ ${s.substringAfterLast('/')}: ${r.out}")
            }
            eng.openStaging(st)
            if (zip) {
                for (s in srcs) {
                    val n = s.substringAfterLast('/')
                    if (n.lowercase().endsWith(".zip")) {
                        val f = File(stagingDir(), n)
                        try {
                            if (f.isFile) { f.inputStream().use { PanelStore.unzip(it, stagingDir()) }; f.delete(); log("  extracted $n") }
                        } catch (e: Exception) { log("✗ zip $n: ${e.message}") }
                    }
                }
            }
            refreshStaged()
            log("✓ ${srcs.size} item(s) added")
            runOnUiThread { storageBrowse(again) }
        }
    }

    // ---------------- system pickers ----------------
    private fun pickFiles() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }, 1)
    }

    private fun pickFolder() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 2)
    }

    private fun showImportMenu() {
        val opts = arrayOf("Pick panel file(s) or .zip", "Pick folder", "Copy template")
        AlertDialog.Builder(this).setTitle("Import Panel").setItems(opts) { _, w ->
            if (w == 0) {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }, 11)
            } else if (w == 1) {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), 12)
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("panel", PanelStore.TEMPLATE))
                toast("Template copied")
            }
        }.show()
    }

    private fun displayName(u: Uri): String {
        var name = "file"
        contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        return safeName(name)
    }

    private fun collectUris(data: Intent): LinkedHashSet<Uri> {
        val uris = LinkedHashSet<Uri>()
        data.clipData?.let { c -> for (i in 0 until c.itemCount) uris.add(c.getItemAt(i).uri) }
        data.data?.let { uris.add(it) }
        return uris
    }

    private fun finishPanelImport(tmp: File) {
        val err = PanelStore.finalize(this, tmp)
        if (err == null) {
            toast("Panel imported")
            runOnUiThread { refreshPanels() }
        } else {
            toast("✗ $err")
            log("✗ Import: $err")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val zip = zipCheck.isChecked
        if (requestCode == 1) {
            val uris = collectUris(data)
            Thread {
                for (u in uris) importUri(u, zip)
                refreshStaged()
                log("✓ ${uris.size} item(s) added")
            }.start()
        } else if (requestCode == 2) {
            val tree = data.data ?: return
            Thread {
                try {
                    val d = DocumentFile.fromTreeUri(this, tree)
                    if (d != null) copyTree(d, File(stagingDir(), safeName(d.name ?: "folder")))
                    log("✓ Folder added: ${d?.name}")
                } catch (e: Exception) { log("✗ Folder: ${e.message}") }
                refreshStaged()
            }.start()
        } else if (requestCode == 11) {
            val uris = collectUris(data)
            val tmp = File(PanelStore.root(this), ".tmp-${System.currentTimeMillis()}")
            Thread {
                try {
                    tmp.mkdirs()
                    for (u in uris) {
                        val name = displayName(u)
                        val input = contentResolver.openInputStream(u) ?: continue
                        input.use {
                            if (name.lowercase().endsWith(".zip")) PanelStore.unzip(it, tmp)
                            else File(tmp, name).outputStream().use { o -> it.copyTo(o) }
                        }
                    }
                    finishPanelImport(tmp)
                } catch (e: Exception) {
                    tmp.deleteRecursively()
                    toast("✗ Import failed: ${e.message}")
                }
            }.start()
        } else if (requestCode == 12) {
            val tree = data.data ?: return
            val tmp = File(PanelStore.root(this), ".tmp-${System.currentTimeMillis()}")
            Thread {
                try {
                    tmp.mkdirs()
                    val d = DocumentFile.fromTreeUri(this, tree)
                    if (d != null) copyTree(d, tmp)
                    finishPanelImport(tmp)
                } catch (e: Exception) {
                    tmp.deleteRecursively()
                    toast("✗ Import failed: ${e.message}")
                }
            }.start()
        }
    }

    private fun importUri(u: Uri, zip: Boolean) {
        val name = displayName(u)
        try {
            if (zip && name.lowercase().endsWith(".zip")) {
                contentResolver.openInputStream(u)?.use { PanelStore.unzip(it, stagingDir()) }
                log("  extracted $name")
            } else {
                val out = File(stagingDir(), name)
                contentResolver.openInputStream(u)?.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            }
        } catch (e: Exception) { log("✗ $name: ${e.message}") }
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            for (c in src.listFiles()) copyTree(c, File(dst, safeName(c.name ?: "x")))
        } else {
            contentResolver.openInputStream(src.uri)?.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun stageBundled(names: List<String>) {
        Thread {
            for (n in names) {
                try { copyAsset("mods/$pkg/$n", File(stagingDir(), n)) }
                catch (e: Exception) { log("✗ $n: ${e.message}") }
            }
            refreshStaged()
            log("✓ Bundled files added")
        }.start()
    }

    private fun copyAsset(path: String, dest: File) {
        val kids = assets.list(path)
        if (kids != null && kids.isNotEmpty()) {
            dest.mkdirs()
            for (k in kids) copyAsset("$path/$k", File(dest, k))
        } else {
            dest.parentFile?.mkdirs()
            assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    private fun clearStaged() {
        Thread { stagingDir().deleteRecursively(); refreshStaged(); log("List cleared") }.start()
    }

    private fun manage() {
        val files = stagedFiles()
        if (files.isEmpty()) { log("List is empty."); return }
        val names = files.map { rel(it) }.toTypedArray()
        val checked = BooleanArray(files.size) { true }
        AlertDialog.Builder(this).setTitle("Keep checked files")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Apply") { _, _ ->
                files.forEachIndexed { i, f -> if (!checked[i]) f.delete() }
                val root = stagingDir()
                root.walkBottomUp().toList()
                    .filter { it.isDirectory && it != root && it.list().isNullOrEmpty() }
                    .forEach { it.delete() }
                refreshStaged()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- damaged file detection ----------------
    private fun findProblems(files: List<File>): Map<File, String> {
        val out = LinkedHashMap<File, String>()
        for (f in files) {
            if (f.length() == 0L) { out[f] = "empty (0 bytes)"; continue }
            val n = f.name.lowercase()
            if (n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".jar")) {
                try {
                    java.util.zip.ZipFile(f).use { }
                } catch (e: Exception) {
                    out[f] = "corrupted or truncated archive (${e.message})"
                }
            }
        }
        return out
    }

    private fun checkStagedUi() {
        val files = stagedFiles()
        if (files.isEmpty()) { log("List is empty."); return }
        val p = findProblems(files)
        if (p.isEmpty()) log("✓ ${files.size} file(s) look healthy")
        else for ((f, m) in p) log("✗ ${f.name}: $m")
    }

    private fun doCheck() {
        val entries = Injector.injected(this, pkg)
        if (entries.isEmpty()) { log("Nothing injected yet."); return }
        val files = stagedFiles()
        log("→ Checking ${entries.size} injected file(s)...")
        withShell { ActionEngine(it, ::log).checkInjected(pkg, entries, files) }
    }

    // ---------------- panel / preset management ----------------
    private fun deletePanel() {
        val p = selectedPanel() ?: run { toast("No panel selected"); return }
        AlertDialog.Builder(this).setTitle("Delete panel \"${p.name}\"?")
            .setPositiveButton("Delete") { _, _ -> p.dir.deleteRecursively(); refreshPanels() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun refreshPresets() {
        presets = presetRoot().listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()
        presetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            if (presets.isEmpty()) listOf("(no presets)") else presets)
    }

    private fun selectedPreset(): String? = presets.getOrNull(presetSpinner.selectedItemPosition)

    private fun savePreset() {
        val script = scriptEdit.text.toString()
        if (stagedFiles().isEmpty() && script.isBlank()) { log("✗ Nothing to save."); return }
        val et = EditText(this)
        et.hint = "Preset name"
        AlertDialog.Builder(this).setTitle("Save preset").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val name = et.text.toString().trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
                if (name.isNotEmpty()) {
                    val meta = JSONObject()
                        .put("sub", subEdit.text.toString().trim())
                        .put("script", script)
                        .put("target", targetSpinner.selectedItemPosition)
                        .put("lock", lockCheck.isChecked)
                        .put("stop", stopCheck.isChecked)
                    Thread {
                        val d = File(presetRoot(), name)
                        d.deleteRecursively()
                        val fd = File(d, "files")
                        fd.mkdirs()
                        stagingDir().copyRecursively(fd, true)
                        File(d, "preset.json").writeText(meta.toString())
                        runOnUiThread { refreshPresets() }
                        log("✓ Preset '$name' saved")
                    }.start()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun loadPreset() {
        val name = selectedPreset() ?: run { log("✗ No presets."); return }
        Thread {
            val d = File(presetRoot(), name)
            stagingDir().deleteRecursively()
            val fd = File(d, "files")
            val src = if (fd.exists()) fd else d
            src.copyRecursively(stagingDir(), true)
            val mf = File(d, "preset.json").let { if (it.exists()) it else File(d, "panel.json") }
            val meta = if (mf.exists()) JSONObject(mf.readText()) else null
            runOnUiThread {
                if (meta != null) {
                    subEdit.setText(meta.optString("sub"))
                    scriptEdit.setText(meta.optString("script"))
                    val pos = meta.optInt("target", 0)
                    if (pos in 0 until cfg.targets.size) targetSpinner.setSelection(pos)
                    lockCheck.isChecked = meta.optBoolean("lock", false)
                    stopCheck.isChecked = meta.optBoolean("stop", true)
                }
                refreshStaged()
                log("✓ Preset '$name' loaded")
            }
        }.start()
    }

    private fun deletePreset() {
        val name = selectedPreset() ?: run { log("✗ No presets."); return }
        AlertDialog.Builder(this).setTitle("Delete preset '$name'?")
            .setPositiveButton("Delete") { _, _ ->
                File(presetRoot(), name).deleteRecursively()
                refreshPresets()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- folder browser for the target ----------------
    private fun browse(subArg: String?) {
        val t = cfg.targets[targetSpinner.selectedItemPosition]
        if (t.needsRoot && !isRoot()) { log("✗ This folder needs Root mode."); return }
        val base = t.path.replace("{pkg}", pkg)
        val cur = subArg ?: subEdit.text.toString().trim().trim('/')
        val dir = if (cur.isEmpty()) base else "$base/$cur"
        withShell { sh ->
            val eng = ActionEngine(sh, ::log)
            if (!eng.isSafe(dir, pkg)) { log("✗ Path rejected: $dir"); return@withShell }
            val res = eng.listDir(dir)
            if (res == null) { log("✗ Cannot open $dir (folder may not exist yet)"); return@withShell }
            val dirs = res.first
            val files = res.second
            val items = (listOf("⬆ Up", "✔ Select this folder")
                + dirs.map { "📁 $it" } + files.map { "📄 $it" }).toTypedArray()
            runOnUiThread {
                AlertDialog.Builder(this).setTitle(dir.removePrefix(STORAGE))
                    .setItems(items) { _, which ->
                        if (which == 0) browse(cur.substringBeforeLast('/', ""))
                        else if (which == 1) subEdit.setText(cur)
                        else if (which < 2 + dirs.size) {
                            val d = dirs[which - 2]
                            browse(if (cur.isEmpty()) d else "$cur/$d")
                        } else browse(cur)
                    }
                    .setNegativeButton("Close", null).show()
            }
        }
    }

    // ---------------- other actions ----------------
    private fun runScriptNow() {
        val s = scriptEdit.text.toString().trim()
        if (s.isEmpty()) { log("✗ Script is empty."); return }
        val dir = fullDir(cfg.targets[targetSpinner.selectedItemPosition])
        val st = stagingDir().absolutePath
        AlertDialog.Builder(this).setTitle("Run script as ${if (isRoot()) "Root" else "Shizuku"}?")
            .setMessage(s.take(600))
            .setPositiveButton("Run") { _, _ ->
                log("▶ Running script...")
                withShell { ActionEngine(it, ::log).runScript(pkg, dir, st, s) }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun doRestore() {
        val dir = resolveDir() ?: return
        withShell { ActionEngine(it, ::log).restore(pkg, dir, Injector.backupRoot(this)) }
    }

    private fun doUnlock() {
        val dir = resolveDir() ?: return
        withShell { ActionEngine(it, ::log).unlock(pkg, dir) }
    }

    private fun doClean() {
        val paths = cfg.junk.map { it.replace("{pkg}", pkg) }
            .filter { isRoot() || !it.startsWith("/data/") }
        withShell { ActionEngine(it, ::log).clean(pkg, paths) }
    }
}
