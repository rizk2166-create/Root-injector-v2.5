package com.rootinjector.app.core

import android.os.Handler
import android.os.Looper

object ShellProvider {
    // onResult selalu dipanggil di main thread
    fun get(root: Boolean, onResult: (Shell?, String?) -> Unit) {
        if (root) {
            Thread {
                val sh = RootShell()
                val r = sh.exec("id")
                val ok = r.code == 0 && r.out.contains("uid=0")
                Handler(Looper.getMainLooper()).post {
                    if (ok) onResult(sh, null) else onResult(null, "Root tidak tersedia: ${r.out}")
                }
            }.start()
        } else {
            ShizukuConnector.connect(onResult)
        }
    }
}
