package com.rootinjector.app.core

import java.io.File

class ActionEngine(private val sh: Shell, private val log: (String) -> Unit) {

    companion object {
        fun quote(s: String) = "'" + s.replace("'", "'\\''") + "'"
    }

    // Root can run in another mount namespace: detect the storage path the shell really sees.
    private val base: String by lazy {
        var found = "/storage/emulated/0"
        for (c in listOf("/storage/emulated/0", "/sdcard", "/data/media/0")) {
            if (sh.exec("[ -d ${quote("$c/Android")} ] && echo ok").out.contains("ok")) { found = c; break }
        }
        found
    }

    private fun m(p: String) =
        if (p.startsWith("/storage/emulated/0")) base + p.removePrefix("/storage/emulated/0") else p

    private fun q(s: String) = quote(m(s))
    fun qp(s: String) = q(s)

    private fun u(p: String): String =
        if (base != "/storage/emulated/0" && p.startsWith(base)) "/storage/emulated/0" + p.removePrefix(base) else p

    // Only folders that belong to the exact target package are allowed
    fun isSafe(path: String, pkg: String): Boolean {
        if (pkg.isBlank() || path.contains("..") || path.contains('\n')) return false
        val roots = listOf(
            "/storage/emulated/0/Android/data/$pkg",
            "/storage/emulated/0/Android/obb/$pkg",
            "/data/data/$pkg",
            "/data/user/0/$pkg"
        )
        return roots.any { path == it || path.startsWith("$it/") }
    }

    fun listDir(dir: String): Pair<List<String>, List<String>>? {
        val cmd = "cd ${q(dir)} 2>/dev/null || exit 3; " +
            "for f in * .[!.]* ..?*; do " +
            "if [ -d \"\$f\" ]; then echo \"\$f/\"; elif [ -e \"\$f\" ]; then echo \"\$f\"; fi; done"
        val r = sh.exec(cmd)
        if (r.code != 0) return null
        val names = r.out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val dirs = names.filter { it.endsWith("/") }.map { it.trimEnd('/') }.sorted()
        val files = names.filter { !it.endsWith("/") }.sorted()
        return Pair(dirs, files)
    }

    fun readFile(path: String): String = sh.exec("cat ${q(path)}").out

    fun copyIn(src: String, stagingDir: String): ShellResult =
        sh.exec("mkdir -p ${q(stagingDir)}; cp -rf ${q(src)} ${q(stagingDir)}/")

    fun openStaging(stagingDir: String) {
        sh.exec("chmod -R 777 ${q(stagingDir)}")
    }

    private fun sha(path: String): String {
        val h = sh.exec("sha256sum ${q(path)} 2>/dev/null").out.trim().substringBefore(' ')
        if (h.length == 64) return h
        val md = sh.exec("md5sum ${q(path)} 2>/dev/null").out.trim().substringBefore(' ')
        return if (md.length == 32) md else ""
    }

    private fun hint(out: String): String {
        val o = out.lowercase()
        val h = when {
            "permission denied" in o -> "permission denied → use Root / enable Shizuku, or tap Unlock"
            "read-only" in o -> "read-only folder → Root required"
            "no space" in o -> "storage full"
            "no such file" in o -> "file or folder not found → run Diagnose"
            else -> ""
        }
        return if (h.isEmpty()) out else "$out ($h)"
    }

    // Look for files with the same name inside the game's own data / obb folders
    private fun findByName(pkg: String, name: String): List<String> {
        val roots = listOf(
            "/storage/emulated/0/Android/data/$pkg",
            "/storage/emulated/0/Android/obb/$pkg",
            "/data/data/$pkg"
        )
        val out = ArrayList<String>()
        for (r in roots) {
            val res = sh.exec("find ${q(r)} -type f -name ${quote(name)} 2>/dev/null")
            res.out.lines().map { it.trim() }.filter { it.startsWith("/") }.forEach { out.add(u(it)) }
        }
        return out.distinct()
    }

    fun inject(
        pkg: String, dir: String, root: File, files: List<File>,
        lock: Boolean, backupRoot: String?, smart: Boolean
    ): List<String> {
        val done = ArrayList<String>()
        if (!isSafe(dir, pkg)) { log("✗ Path rejected (not a folder of $pkg): $dir"); return done }
        val mk = sh.exec("mkdir -p ${q(dir)}")
        if (mk.code != 0) { log("✗ Cannot create folder: ${mk.out}"); return done }

        val internal = dir.startsWith("/data/") || base.startsWith("/data/media")
        val uid = sh.exec("stat -c %u ${q("/data/data/$pkg")}").out.trim()
            .takeIf { it.isNotEmpty() && it.all(Char::isDigit) }

        val cache = HashMap<String, List<String>>()
        val tops = LinkedHashSet<String>()
        var ok = 0
        var bad = 0

        fun put(f: File, rel: String, dst: String) {
            if (f.length() == 0L) { log("✗ ${f.name}: empty file (0 bytes), skipped"); bad++; return }
            val existed = sh.exec("[ -e ${q(dst)} ] && echo ya").out.contains("ya")
            val dstDir = dst.substringBeforeLast('/')
            sh.exec("mkdir -p ${q(dstDir)}")
            val names = cache.getOrPut(dstDir) {
                listDir(dstDir)?.let { it.first + it.second } ?: emptyList()
            }
            if (backupRoot != null) {
                val b = backupRoot + dst
                sh.exec("if [ -e ${q(dst)} ] && [ ! -e ${q(b)} ]; then mkdir -p ${q(b.substringBeforeLast('/'))} && cp -f ${q(dst)} ${q(b)}; fi")
            }
            val baseName = f.nameWithoutExtension
            val ext = if (f.extension.isEmpty()) "" else "." + f.extension
            val dup = Regex("^" + Regex.escape(baseName) + "( \\(\\d+\\)|_copy\\d*|-\\d+)?" + Regex.escape(ext) + "$")
            names.filter { dup.matches(it) }.forEach { n ->
                val p = q("$dstDir/$n")
                sh.exec("chattr -i $p 2>/dev/null; chmod 666 $p 2>/dev/null; rm -rf $p")
                log("  removed old/duplicate: $n")
            }

            val srcSum = sha(f.absolutePath)
            var attempt = 0
            var good = false
            while (attempt < 3 && !good) {
                attempt++
                val r = sh.exec("cp -f ${q(f.absolutePath)} ${q(dst)} && chmod 644 ${q(dst)}")
                if (r.code != 0) {
                    log("  ⚠ attempt $attempt failed: ${hint(r.out)}")
                    continue
                }
                val a = sh.exec("stat -c %s ${q(f.absolutePath)}").out.trim()
                val c = sh.exec("stat -c %s ${q(dst)}").out.trim()
                val dstSum = sha(dst)
                good = if (srcSum.isNotEmpty() && dstSum.isNotEmpty()) srcSum == dstSum else (a.isNotEmpty() && a == c)
                if (!good) log("  ⚠ attempt $attempt: result does not match ($a vs $c bytes), retrying")
            }
            if (!good) {
                bad++
                val bkp = if (backupRoot != null) backupRoot + dst else null
                val restored = bkp != null &&
                    sh.exec("[ -e ${q(bkp)} ] && cp -f ${q(bkp)} ${q(dst)} && echo ok").out.contains("ok")
                if (restored) {
                    log("✗ ${f.name}: failed, original restored from backup")
                } else if (!existed) {
                    sh.exec("rm -f ${q(dst)}")
                    log("✗ ${f.name}: failed after 3 attempts, partial file removed")
                } else {
                    log("✗ ${f.name}: failed and the original was overwritten. Enable Backup to allow restore")
                }
                return
            }
            log("✓ ${f.name} → ${dst.removePrefix("/storage/emulated/0")}")
            ok++
            done.add(dst + "\t" + srcSum)
            if (uid != null && (dst.startsWith("/data/") || base.startsWith("/data/media"))) {
                sh.exec("chown $uid:$uid ${q(dst)}")
            }
            if (lock) sh.exec("chmod 444 ${q(dst)}; chattr +i ${q(dst)} 2>/dev/null")
        }

        for (f in files) {
            val rel = f.relativeTo(root).path.replace(File.separatorChar, '/')
            val relDir = rel.substringBeforeLast('/', "")
            val defaultDst = (if (relDir.isEmpty()) dir else "$dir/$relDir") + "/" + f.name
            var targets = listOf(defaultDst)
            if (smart) {
                val found = findByName(pkg, f.name).filter { isSafe(it, pkg) }
                if (found.isNotEmpty() && found.size <= 5) {
                    targets = found
                    log("  🔎 ${f.name}: ${found.size} original location(s) found, replaced in place")
                } else if (found.size > 5) {
                    log("  ⚠ ${f.name}: ${found.size} locations found (too many), using selected folder")
                }
            }
            if (targets.size == 1 && targets[0] == defaultDst) tops.add(rel.substringBefore('/'))
            targets.forEach { put(f, rel, it) }
        }
        if (internal) {
            tops.forEach { t ->
                if (uid != null) sh.exec("chown -R $uid:$uid ${q("$dir/$t")}")
                sh.exec("restorecon -R ${q("$dir/$t")} 2>/dev/null")
            }
        }
        if (lock) log("🔒 files locked")
        log("Done: $ok succeeded, $bad failed")
        return done
    }

    // Remove injected files; restore the original from backup when there is one
    fun uninject(pkg: String, paths: List<String>, backupRoot: String) {
        var n = 0
        for (p in paths) {
            if (!isSafe(p, pkg)) { log("✗ skipped (unsafe path): $p"); continue }
            sh.exec("chattr -i ${q(p)} 2>/dev/null; chmod 666 ${q(p)} 2>/dev/null; rm -f ${q(p)}")
            val b = backupRoot + p
            val restored = sh.exec("[ -e ${q(b)} ] && cp -f ${q(b)} ${q(p)} && echo restored").out.contains("restored")
            log(if (restored) "↩ restored: ${p.substringAfterLast('/')}" else "✓ deleted: ${p.substringAfterLast('/')}")
            n++
        }
        log("Done: $n file(s)")
    }

    // Verify injected files; re-copy anything that went missing, changed or got corrupted
    fun checkInjected(pkg: String, entries: List<String>, files: List<File>) {
        var okc = 0
        var fixed = 0
        var bad = 0
        for (e in entries) {
            val dst = e.substringBefore('\t')
            val want = if (e.contains('\t')) e.substringAfter('\t') else ""
            val nm = dst.substringAfterLast('/')
            if (!isSafe(dst, pkg)) continue
            val exists = sh.exec("[ -f ${q(dst)} ] && echo ya").out.contains("ya")
            val cur = if (exists) sha(dst) else ""
            if (exists && (want.isEmpty() || cur == want)) { okc++; continue }
            val src = files.firstOrNull { it.name == nm }
            if (src == null) {
                log("✗ $nm: ${if (exists) "changed or corrupted" else "missing"}, source file is not in the list")
                bad++
                continue
            }
            sh.exec("chattr -i ${q(dst)} 2>/dev/null; chmod 666 ${q(dst)} 2>/dev/null")
            val r = sh.exec("cp -f ${q(src.absolutePath)} ${q(dst)} && chmod 644 ${q(dst)}")
            val now = sha(dst)
            if (r.code == 0 && (want.isEmpty() || now == want)) { log("🩹 repaired: $nm"); fixed++ }
            else { log("✗ could not repair $nm: ${hint(r.out)}"); bad++ }
        }
        log("Check done: $okc fine, $fixed repaired, $bad problem(s)")
    }

    fun runScript(pkg: String, dir: String, staging: String, script: String) {
        val env = "export PKG=${quote(pkg)} TARGET=${q(dir)} STAGING=${q(staging)} STORAGE=${quote(base)}; "
        val r = sh.exec(env + script)
        if (r.out.isNotBlank()) r.out.lines().forEach { log("  $it") }
        log(if (r.code == 0) "✓ Script finished" else "✗ Script exited with code ${r.code}")
    }

    fun diagnose(pkg: String, dir: String, staging: String) {
        log("— DIAGNOSE —")
        log("id: " + sh.exec("id").out)
        log("SELinux: " + sh.exec("getenforce").out)
        log("storage path: $base")
        log("staging folder: " + sh.exec("[ -d ${q(staging)} ] && echo OK || echo MISSING").out)
        log("staging content: " + sh.exec("ls ${q(staging)} 2>&1 | head -5").out)
        log("target folder: " + sh.exec("[ -d ${q(dir)} ] && echo OK || echo MISSING").out)
        log("target content: " + sh.exec("ls ${q(dir)} 2>&1 | head -5").out)
        log("— end —")
    }

    fun restore(pkg: String, dir: String, backupRoot: String) {
        if (!isSafe(dir, pkg)) { log("✗ Path rejected: $dir"); return }
        val b = backupRoot + dir
        val chk = sh.exec("[ -d ${q(b)} ] && echo ada")
        if (!chk.out.contains("ada")) {
            log("✗ No backup for $dir (backups are made on inject when Backup is on)"); return
        }
        sh.exec("chattr -i -R ${q(dir)} 2>/dev/null; chmod -R u+w ${q(dir)} 2>/dev/null")
        val r = sh.exec("cp -rf ${q("$b/.")} ${q("$dir/")}")
        log(if (r.code == 0) "✓ Originals restored to $dir" else "✗ ${r.out}")
    }

    fun unlock(pkg: String, dir: String) {
        if (!isSafe(dir, pkg)) { log("✗ Path rejected: $dir"); return }
        sh.exec("chattr -i -R ${q(dir)} 2>/dev/null; chmod -R u+w ${q(dir)} 2>/dev/null")
        log("🔓 Unlocked $dir")
    }

    fun clean(pkg: String, paths: List<String>) {
        for (p in paths) {
            if (!isSafe(p, pkg)) { log("✗ Rejected: $p"); continue }
            val r = sh.exec("rm -rf ${q(p)}")
            log(if (r.code == 0) "✓ deleted $p" else "✗ $p: ${r.out}")
        }
        log("Cache cleared")
    }
}
