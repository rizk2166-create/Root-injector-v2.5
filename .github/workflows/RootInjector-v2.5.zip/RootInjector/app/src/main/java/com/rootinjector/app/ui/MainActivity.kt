package com.rootinjector.app.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.doAfterTextChanged
import com.rootinjector.app.core.CrashLog
import com.rootinjector.app.core.RootShell
import com.rootinjector.app.core.ShizukuConnector
import com.rootinjector.app.data.AppInfo
import com.rootinjector.app.data.GameRepository

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        val all = GameRepository.installedApps(packageManager, packageName)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.fitsSystemWindows = true
        root.setPadding(dp(16), dp(10), dp(16), 0)
        root.addView(tv("Root Injection Panel", 24f, Ui.TEXT, true))

        root.addView(row(
            btn("Root") {
                Thread {
                    val r = RootShell().exec("id")
                    val ok = r.code == 0 && r.out.contains("uid=0")
                    runOnUiThread {
                        Toast.makeText(this, if (ok) "✓ Root OK" else "✗ Root unavailable: ${r.out}", Toast.LENGTH_LONG).show()
                    }
                }.start()
            },
            btn("Shizuku") {
                ShizukuConnector.connect { sh, err ->
                    Toast.makeText(this, if (sh != null) "✓ Shizuku OK" else "✗ $err", Toast.LENGTH_LONG).show()
                }
            },
            btn("Overlay") {
                if (Settings.canDrawOverlays(this)) Toast.makeText(this, "✓ Overlay allowed", Toast.LENGTH_SHORT).show()
                else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        ))

        val search = edit("Search apps")
        root.addView(search)

        val list = ListView(this)
        list.divider = null
        list.dividerHeight = dp(6)
        list.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) }
        root.addView(list)
        setContentView(root)

        val adapter = object : ArrayAdapter<AppInfo>(this, 0, ArrayList(all)) {
            @Suppress("UNCHECKED_CAST")
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val item = getItem(p)!!
                val holder: Triple<ImageView, TextView, TextView>
                val row: View
                if (v == null) {
                    val ic = ImageView(context)
                    ic.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
                    val t1 = tv("", 15f, Ui.TEXT, true)
                    val t2 = tv("", 12f, Ui.SUB)
                    val tx = LinearLayout(context)
                    tx.orientation = LinearLayout.VERTICAL
                    tx.setPadding(dp(12), 0, 0, 0)
                    tx.addView(t1); tx.addView(t2)
                    val r = LinearLayout(context)
                    r.orientation = LinearLayout.HORIZONTAL
                    r.gravity = Gravity.CENTER_VERTICAL
                    r.background = shape(Ui.CARD, 14)
                    r.setPadding(dp(12), dp(10), dp(12), dp(10))
                    r.addView(ic); r.addView(tx)
                    holder = Triple(ic, t1, t2)
                    r.tag = holder
                    row = r
                } else {
                    row = v
                    holder = v.tag as Triple<ImageView, TextView, TextView>
                }
                holder.second.text = item.label
                holder.third.text = item.pkg
                try { holder.first.setImageDrawable(packageManager.getApplicationIcon(item.pkg)) } catch (e: Exception) { }
                return row
            }
        }
        list.adapter = adapter
        search.doAfterTextChanged {
            val k = it.toString().trim().lowercase()
            adapter.clear()
            adapter.addAll(all.filter { a -> a.label.lowercase().contains(k) || a.pkg.lowercase().contains(k) })
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            val app = adapter.getItem(pos)!!
            startActivity(Intent(this, ControlActivity::class.java).apply {
                putExtra("pkg", app.pkg); putExtra("label", app.label)
            })
        }

        CrashLog.take(this)?.let { trace ->
            AlertDialog.Builder(this).setTitle("Last session crashed")
                .setMessage(trace.take(3000))
                .setPositiveButton("Copy") { _, _ ->
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("crash", trace))
                }
                .setNegativeButton("Close", null).show()
        }
    }
}
