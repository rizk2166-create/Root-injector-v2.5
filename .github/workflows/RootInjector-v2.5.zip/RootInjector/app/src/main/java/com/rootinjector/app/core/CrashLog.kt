package com.rootinjector.app.core

import android.content.Context
import android.util.Log
import java.io.File

object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "crash.txt")

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { file(ctx).writeText(Log.getStackTraceString(e)) } catch (x: Throwable) { }
            old?.uncaughtException(t, e)
        }
    }

    fun take(ctx: Context): String? {
        val f = file(ctx)
        if (!f.exists()) return null
        val s = f.readText()
        f.delete()
        return s
    }
}
