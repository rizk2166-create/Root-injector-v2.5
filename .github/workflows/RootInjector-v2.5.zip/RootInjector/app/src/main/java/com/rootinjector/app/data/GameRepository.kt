package com.rootinjector.app.data

import android.content.Context
import android.content.pm.PackageManager
import org.json.JSONObject

data class AppInfo(val label: String, val pkg: String)
data class Target(val label: String, val path: String, val needsRoot: Boolean)
data class Config(val targets: List<Target>, val junk: List<String>)

object GameRepository {
    fun installedApps(pm: PackageManager, self: String): List<AppInfo> =
        pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != self }
            .map { AppInfo(pm.getApplicationLabel(it).toString(), it.packageName) }
            .sortedBy { it.label.lowercase() }

    fun loadConfig(ctx: Context): Config {
        val json = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
        val t = json.getJSONArray("targets")
        val targets = (0 until t.length()).map {
            val o = t.getJSONObject(it)
            Target(o.getString("label"), o.getString("path"), o.optBoolean("needs_root", false))
        }
        val j = json.getJSONArray("junk")
        return Config(targets, (0 until j.length()).map { j.getString(it) })
    }

    fun bundledMods(ctx: Context, pkg: String): List<String> =
        ctx.assets.list("mods/$pkg")?.toList() ?: emptyList()
}
